DROP SEQUENCE IF EXISTS _fedex.outbound_writeback_id_seq CASCADE;
DROP TABLE IF EXISTS _fedex.outbound_writeback CASCADE;
DROP VIEW IF EXISTS _fedex.outbound CASCADE;