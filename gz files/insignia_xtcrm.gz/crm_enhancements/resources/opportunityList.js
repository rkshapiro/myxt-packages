//opportunityList

var _list = mywindow.findChild("_list");

_list.addColumn("Last Contacted", XTreeWidget.dateColumn, Qt.AlignRight, true, "f_lastcontacteddate");


