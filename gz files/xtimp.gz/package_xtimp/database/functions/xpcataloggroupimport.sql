-- Function: xtimp.xpcataloggroupimport()

-- DROP FUNCTION xtimp.xpcataloggroupimport();

CREATE OR REPLACE FUNCTION xtimp.xpcataloggroupimport()
  RETURNS boolean AS
$BODY$
-- Copyright (c) 1999-2012 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/CPAL for the full text of the software license.
DECLARE
  _r  RECORD;
  _result INTEGER;
  _catalogid INTEGER;
  _groupitemnameid INTEGER;

BEGIN 
-- get the id for the catalog group
  SELECT itemgrp_id INTO _catalogid FROM itemgrp WHERE itemgrp_catalog;
  
  FOR _r IN
  -- select all of the group items and get the id of ones already imported
   (
     SELECT *,itemgrp_id
	 FROM xtimp.xpcataloggroup
	 LEFT OUTER JOIN itemgrp ON xpcataloggroup_groupitemname = itemgrp_name
	 WHERE xpcataloggroup_id >0
     AND xpcataloggroup_checked='t'
   ) 
   LOOP
	IF _r.itemgrp_id IS NULL THEN
		INSERT INTO itemgrp(itemgrp_name)
		VALUES (_r.xpcataloggroup_groupitemname)
		RETURNING itemgrp_id INTO _groupitemnameid;
	END IF;

	INSERT INTO itemgrpitem(itemgrpitem_itemgrp_id, itemgrpitem_item_id,itemgrpitem_item_type)
	VALUES (_catalogid,COALESCE(_r.itemgrp_id,_groupitemnameid),'G');
    
  END LOOP;
  
  UPDATE xtimp.xpcataloggroup
  SET xpcataloggroup_imported = true
  WHERE xpcataloggroup_import_error = '';
    
  RAISE NOTICE  'extimp catalog group import completed';
  RETURN(TRUE);
  END; 

$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION xtimp.xpcataloggroupimport()
  OWNER TO admin;