mywindow.setWindowTitle(qsTr("All Item Prices"));
mywindow.setMetaSQLOptions('price', 'all');
mywindow.setQueryOnStartEnabled(true);
mywindow.setSearchVisible(true);
var _search=toolbox.createWidget("QToolButton", mywindow.toolBar(), "_search");
_search.text=qsTr("Product Category");
var _searchAct=mywindow.toolBar().insertWidget(mywindow.querySeparator(), _search);

var _list = mywindow.list();

  _list.addColumn(qsTr("Item Number"), XTreeWidget.itemColumn,     Qt.AlignLeft,   true,  "item_number"  );
  _list.addColumn(qsTr("Description"), -1, Qt.AlignLeft,   true,  "item_descrip1"  );
  _list.addColumn(qsTr("Barcode"), -1, Qt.AlignLeft,   true,  "item_upccode"  );
 // _list.addColumn(qsTr("Price Sched"), XTreeWidget.itemColumn,     Qt.AlignLeft,   true,  "ipshead_name"  );
  _list.addColumn(qsTr("INV UOM"),     XTreeWidget.uomColumn,        Qt.AlignCenter, true,  "qtyuom" );
//  _list.addColumn(qsTr("QTY Break"),  XTreeWidget.qtyColumn,      Qt.AlignLeft,  true,  "qtybreak" );
  _list.addColumn(qsTr("Price UOM"),   XTreeWidget.uomColumn,      Qt.AlignCenter, true,  "priceuom" );
  _list.addColumn(qsTr("List Price"),  XTreeWidget.priceColumn,    Qt.AlignLeft,  true,  "item_listprice" );
 // _list.addColumn(qsTr("Net Price"),   XTreeWidget.priceColumn,   Qt.AlignLeft,   true,  "netprice" );
  _list.addColumn(qsTr("STD Cost"),    XTreeWidget.priceColumn,   Qt.AlignLeft,   true,  "itemcost_stdcost" );
  _list.addColumn(qsTr("ACT Cost"),    XTreeWidget.priceColumn,   Qt.AlignLeft,   true,  "itemcost_actcost" );
  _list.addColumn(qsTr("Prodcat"),        -1, 		Qt.AlignLeft,   true,  "prodcat_code" );
  _list.addColumn(qsTr("Item Exclusive"),      -1,   		Qt.AlignLeft,  true,  "item_exclusive" );



