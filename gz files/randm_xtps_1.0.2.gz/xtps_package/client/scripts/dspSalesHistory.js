// dspSalesHistory

var _list = mywindow.findChild("_list");

_list.addColumn(qsTr("ShipTo State"), -1, 1, true, "cohist_shiptostate");
_list.addColumn(qsTr("ShipTo Country"), -1, 1, true, "cohist_shiptocountry");
_list.addColumn(qsTr("True Cost"), -1, 2, true, "true_cost");
_list.addColumn(qsTr("True Ext Cost"), -1, 2, true, "extTcost");
_list.addColumn(qsTr("True Margin"), -1, 2, true, "Tmargin");
_list.addColumn(qsTr("True Margin %"), -1, 2, true, "Tmarginpercent");