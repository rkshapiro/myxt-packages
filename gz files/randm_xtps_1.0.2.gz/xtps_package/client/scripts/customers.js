﻿// customers
var _list = mywindow.findChild("_list");

_list.addColumn(qsTr("Sales Rep"), -1, 1, true, "sales_rep");