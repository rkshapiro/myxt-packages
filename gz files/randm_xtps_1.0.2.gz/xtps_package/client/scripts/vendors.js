﻿// vendors

var _list = mywindow.findChild("_list");

_list.addColumn(qsTr("Expense Accnt"), -1, 1, true, "exp_accnt");