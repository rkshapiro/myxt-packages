 var menuSales = mainwindow.findChild("menu.sales");
  var salesPricingMenu = mainwindow.findChild("menu.sales.pricingreports");


function sPricesAll()

{
  try {
    toolbox.newDisplay("pricesAll", 0, Qt.NonModal, Qt.Window);
  } catch (e) {
    print("initMenu::sPricesAll() exception @ " + e.lineNumber + ": " + e);
  }
}


var salesPricingMenu  = mainwindow.findChild("menu.sales.pricingreports");
salesPricingMenu.addSeparator();

  var qprice = salesPricingMenu.addAction(qsTr("All Item Prices..."));

 
  qprice.triggered.connect(sPricesAll);
