-- Function: xtps._truecostupdate()

-- DROP FUNCTION xtps._truecostupdate();

CREATE OR REPLACE FUNCTION xtps._truecostupdate()
  RETURNS trigger AS
$BODY$
-- Copyright (c) 1999-2017 by OpenMFG LLC, d/b/a xTuple.
-- See www.xtuple.com/EULA for the full text of the software license.
DECLARE
_truecost numeric := 0.0;

BEGIN
IF TG_TABLE_NAME = 'itemcost' THEN
	SELECT  xtps.truecostupdate(NEW.itemcost_item_id) INTO _truecost;
    UPDATE item		
     SET item_listcost = coalesce(_truecost,0.0)
     WHERE item_id = NEW.itemcost_item_id;
END IF;
IF TG_TABLE_NAME = 'item' THEN
	SELECT  xtps.truecostupdate(NEW.item_id) INTO _truecost;
    NEW.item_listcost := coalesce(_truecost,0.0);
END IF;
 RETURN NEW;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION xtps._truecostupdate()
  OWNER TO admin;
  
-- Trigger: itemxtpstruecosttrigger on public.item

DROP TRIGGER IF EXISTS itemxtpstruecosttrigger ON public.item;

CREATE TRIGGER itemxtpstruecosttrigger
  BEFORE INSERT OR UPDATE
  ON public.item
  FOR EACH ROW
  EXECUTE PROCEDURE xtps._truecostupdate();
  
-- Trigger: itemxtpstruecosttrigger on public.itemcost

DROP TRIGGER IF EXISTS itemxtpstruecosttrigger ON public.itemcost;

CREATE TRIGGER itemxtpstruecosttrigger
  AFTER INSERT OR UPDATE
  ON public.itemcost
  FOR EACH ROW
  EXECUTE PROCEDURE xtps._truecostupdate();
