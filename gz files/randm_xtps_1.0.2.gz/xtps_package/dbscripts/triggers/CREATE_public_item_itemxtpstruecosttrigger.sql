-- Trigger: itemxtpstruecosttrigger on public.item

DROP TRIGGER IF EXISTS itemxtpstruecosttrigger ON public.item;

CREATE TRIGGER itemxtpstruecosttrigger
  BEFORE INSERT OR UPDATE
  ON public.item
  FOR EACH ROW
  EXECUTE PROCEDURE xtps._truecostupdate();
