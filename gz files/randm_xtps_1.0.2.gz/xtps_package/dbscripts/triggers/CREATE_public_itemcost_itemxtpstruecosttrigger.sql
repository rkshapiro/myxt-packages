-- Trigger: itemxtpstruecosttrigger on public.itemcost

DROP TRIGGER IF EXISTS itemxtpstruecosttrigger ON public.itemcost;

CREATE TRIGGER itemxtpstruecosttrigger
  AFTER INSERT OR UPDATE
  ON public.itemcost
  FOR EACH ROW
  EXECUTE PROCEDURE xtps._truecostupdate();
