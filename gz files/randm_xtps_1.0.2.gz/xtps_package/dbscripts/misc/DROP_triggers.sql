-- drop triggers
DROP TRIGGER IF EXISTS itemxtpstruecosttrigger on item;
DROP TRIGGER IF EXISTS itemxtpstruecosttrigger on itemcost;
