-- Function: xtps.getcomment(text,text,integer)

-- DROP FUNCTION xtps.getcomment(text,text,integer);

CREATE OR REPLACE FUNCTION xtps.getcomment(text,text,integer)
  RETURNS text AS
$BODY$
-- Copyright (c) 1999-2014 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/CPAL for the full text of the software license.
DECLARE
  pCmntType ALIAS FOR $1;
  pCmntSource ALIAS FOR $2;
  pCmntSourceId ALIAS FOR $3;
  _returnVal TEXT;
BEGIN
  IF (COALESCE(TRIM(pCmntType), '') = '') THEN
    RETURN NULL;
  END IF;
  
  IF (COALESCE(TRIM(pCmntSource), '') = '') THEN
    RETURN NULL;
  END IF;
  
  IF (pCmntSourceId = NULL) THEN
    RETURN NULL;
  END IF;
  
  IF (getcmnttypeid(pCmntType) IS NULL) THEN
	RAISE EXCEPTION 'Comment Type % not found.', pCmntType;
  END IF;

  SELECT comment_text INTO _returnVal
  FROM comment
  WHERE comment_cmnttype_id = getcmnttypeid(pCmntType)
  AND comment_source = pCmntSource
  AND comment_source_id = pCmntSourceId
  ORDER BY comment_date DESC
  LIMIT 1;

  RETURN _returnVal;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION xtps.getcomment(text,text,integer)
  OWNER TO admin;
