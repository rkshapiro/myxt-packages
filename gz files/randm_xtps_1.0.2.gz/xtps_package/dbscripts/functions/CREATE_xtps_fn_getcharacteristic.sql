-- Function: xtps.getcharacteristic(text,text,integer)

-- DROP FUNCTION xtps.getcharacteristic(text,text,integer);

CREATE OR REPLACE FUNCTION xtps.getcharacteristic(text,text,integer)
  RETURNS text AS
$BODY$
-- Copyright (c) 1999-2014 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/CPAL for the full text of the software license.
DECLARE
  pCharName ALIAS FOR $1;
  pTargetType ALIAS FOR $2;
  pTargetId ALIAS FOR $3;
  _returnVal TEXT;
BEGIN
  IF (COALESCE(TRIM(pCharName), '') = '') THEN
    RETURN NULL;
  END IF;
  
  IF (COALESCE(TRIM(pTargetType), '') = '') THEN
    RETURN NULL;
  END IF;
  
  IF (pTargetId = NULL) THEN
    RETURN NULL;
  END IF;
  
  IF (getcharid(pCharName) IS NULL) THEN
	RAISE EXCEPTION 'Characteristic % not found.', pCharName;
  END IF;

  SELECT charass_value INTO _returnVal
  FROM charass
  WHERE charass_target_id = pTargetId
  AND charass_target_type = pTargetType
  AND charass_char_id = getcharid(pCharName)
  ORDER BY charass_id DESC
  LIMIT 1;

  RETURN _returnVal;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION xtps.getcharacteristic(text,text,integer)
  OWNER TO admin;
