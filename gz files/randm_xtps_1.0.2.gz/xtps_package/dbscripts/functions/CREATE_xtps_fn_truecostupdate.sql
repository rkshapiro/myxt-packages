-- Function: xtps.truecostupdate(integer)

-- DROP FUNCTION xtps.truecostupdate(integer);

CREATE OR REPLACE FUNCTION xtps.truecostupdate(integer)
  RETURNS numeric AS
$BODY$
-- Copyright (c) 1999-2017 by OpenMFG LLC, d/b/a xTuple. 
-- See www.xtuple.com/EULA for the full text of the software license.
DECLARE 
   pItemid ALIAS FOR $1; 
  _itemcost NUMERIC(16,6) :=0;
  _labor NUMERIC(16,6) :=0;
  _itemstdcost NUMERIC(16,6) :=0;
  _itemtype TEXT;
BEGIN

-- Get itemtype
  SELECT item_type INTO _itemtype 
  FROM item
  WHERE item_id= pItemid;
  
   --Get itemcost_stdcost
  SELECT itemcost_stdcost INTO _itemstdcost 
  FROM itemcost
  JOIN costelem ON ( itemcost_costelem_id=costelem_id)
  WHERE costelem_type='Material'
  AND itemcost_item_id=pItemid
  LIMIT 1;
  
  IF _itemtype= 'M' THEN
  --get itemcost
     SELECT SUM(bomcost/ xwd.convtonum(charass_value)) INTO _itemcost
     FROM( SELECT  (bomitem_qtyper * itemcost_actcost)  as bomcost, charass_value
         FROM bomitem
         JOIN char ON ( char_name ~* 'Landed Cost')
         JOIN charass ON ( char_id= charass_char_id)AND (charass_target_id=bomitem_item_id)
         LEFT OUTER JOIN itemcost ON (bomitem_item_id=itemcost_item_id)
    WHERE (bomitem_parent_item_id=pItemid)
	AND (bomitem_expires >= (CURRENT_DATE))
	GROUP BY charass_value, bomitem_qtyper, itemcost_actcost) AS costtotal;
	
	IF (NOT FOUND) THEN
    RAISE EXCEPTION ' pItemid % requires bomitems',pItemid;
	END IF;
  END IF;

  SELECT xwd.convtonum(charass_value) INTO _labor
    FROM charass
    LEFT JOIN char ON (char_name ~* 'labor cost')
    WHERE (charass_target_id=pItemid) AND char_id=charass_char_id;

  IF _itemtype= 'P' THEN  
      SELECT  
      (itemcost_stdcost/ xwd.convtonum(charass_value))  INTO _itemcost
        FROM itemcost
        LEFT JOIN char ON ( char_name ~* 'Landed Cost')
        LEFT JOIN charass ON ( char_id= charass_char_id)AND (charass_target_id=itemcost_item_id)  
      WHERE (itemcost_item_id=pItemid);
  END IF;	 
  --  update Wholesale Price
  IF _itemtype ='M' THEN
     RETURN (_itemcost + coalesce(_labor,0.0) + _itemstdcost);
  END IF;
	
  IF _itemtype='P' THEN	
     RETURN (_itemcost + _itemstdcost);
  END IF;
	
RETURN NULL;
END;
$BODY$
  LANGUAGE plpgsql VOLATILE
  COST 100;
ALTER FUNCTION xtps.truecostupdate(integer)
  OWNER TO admin;
