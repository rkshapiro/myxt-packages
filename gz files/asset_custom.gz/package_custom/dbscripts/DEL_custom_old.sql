DROP FUNCTION IF EXISTS _custom.araging CASCADE;
DROP FUNCTION IF EXISTS _custom.calcshipfreight CASCADE;
DROP FUNCTION IF EXISTS _custom.freightdetail CASCADE;
DROP VIEW IF EXISTS _custom.saleshistory CASCADE;