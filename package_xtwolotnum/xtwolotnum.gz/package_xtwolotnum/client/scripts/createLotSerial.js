﻿var _lotSerial = mywindow.findChild("_lotSerial");

function set(input) {
  _lotSerial.text = "";
}