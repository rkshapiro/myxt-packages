CREATE TABLE xtsqrimp.sqrimp
(
sqrimp_id serial NOT NULL,
sqrimp_date TEXT,
sqrimp_time TEXT, 
sqrimp_timezone TEXT, 
sqrimp_category TEXT, 
sqrimp_item TEXT, 
sqrimp_qty TEXT, 
sqrimp_pricepointname TEXT, 
sqrimp_sku TEXT, 
sqrimp_modifiersapplied TEXT, 
sqrimp_grosssales TEXT, 
sqrimp_discounts TEXT, 
sqrimp_netsales TEXT, 
sqrimp_tax TEXT, 
sqrimp_transactionid TEXT, 
sqrimp_paymentid TEXT, 
sqrimp_devicename TEXT, 
sqrimp_notes TEXT, 
sqrimp_details TEXT, 
sqrimp_eventtype TEXT, 
sqrimp_location TEXT, 
sqrimp_diningoption TEXT, 
sqrimp_customerid TEXT, 
sqrimp_customername TEXT, 
sqrimp_customerreferenceid TEXT,
sqrimp_status TEXT,
sqrimp_invcnum TEXT,
  CONSTRAINT sqrimp_pkey PRIMARY KEY (sqrimp_id)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE xtsqrimp.sqrimp OWNER TO "admin";
GRANT ALL ON TABLE xtsqrimp.sqrimp TO "admin";
GRANT ALL ON TABLE xtsqrimp.sqrimp TO xtrole;